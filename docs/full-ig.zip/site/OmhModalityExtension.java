package http://www.fhir.org/guides/omhtofhir/ImplementationGuide/openmhealth.mfhir-0.0.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class OmhModalityExtension {

}
